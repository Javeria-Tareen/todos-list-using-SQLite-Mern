// backend/models/todoModel.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db'); // Ensure the path to db.js is correct

// Define the Todo model
const Todo = sequelize.define('Todo', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  completed: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
}, {
  tableName: 'todos', // Optional: Explicitly define the table name if necessary
  timestamps: true,   // Automatically manage createdAt and updatedAt
});

module.exports = { Todo };
