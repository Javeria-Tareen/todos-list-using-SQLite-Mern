// backend/routes/todoRoutes.js
const express = require('express');
const router = express.Router();
const todoController = require('../controllers/todoController');

// Routes for todos
router.get('/todos', todoController.getTodos);               // Get all todos
router.get('/todos/:id', todoController.getTodoById);        // Get a single todo by ID
router.post('/todos', todoController.createTodo);            // Create a new todo
router.put('/todos/:id', todoController.updateTodo);         // Update an existing todo
router.delete('/todos/:id', todoController.deleteTodo);      // Delete a todo

module.exports = router;
