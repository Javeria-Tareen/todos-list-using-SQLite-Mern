// backend/config/db.js
const { Sequelize } = require('sequelize');

// Create a Sequelize instance connected to the SQLite database
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite', // Path to your SQLite file
});

module.exports = sequelize;