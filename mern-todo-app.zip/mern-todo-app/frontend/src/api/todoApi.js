import axios from 'axios';

const API_URL = 'http://localhost:5000/api/todos';

// Get all todos
export const getTodos = async () => {
  return axios.get(API_URL);
};

// Create a new todo
export const createTodo = async (todo) => {
  return axios.post(API_URL, todo);
};

// Update a todo
export const updateTodo = async (id, todo) => {
  return axios.put(`${API_URL}/${id}`, todo);
};

// Delete a todo
export const deleteTodo = async (id) => {
  return axios.delete(`${API_URL}/${id}`);
};
