import React from 'react';
import TodoList from '../components/TodoList';
import '../styles/HomePage.css';

const HomePage = () => {
  return (
    <div className="home-page">
      <div className="main-content">
        <TodoList />
      </div>
    </div>
  );
};

export default HomePage;
