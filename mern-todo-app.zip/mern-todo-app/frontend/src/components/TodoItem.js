import React from 'react';
import axios from 'axios';
import '../styles/TodoItem.css';

const TodoItem = ({ todo, onDeleteTodo, onUpdateTodo }) => {
  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:5000/api/todos/${todo.id}`);
      onDeleteTodo(todo.id); // Notify parent to remove the todo from the state
    } catch (error) {
      console.error('Error deleting todo:', error);
    }
  };

  const handleComplete = async () => {
    try {
      const updatedTodo = { ...todo, completed: !todo.completed };
      await axios.put(`http://localhost:5000/api/todos/${todo.id}`, updatedTodo);
      onUpdateTodo(updatedTodo); // Notify parent to update the todo in the state
    } catch (error) {
      console.error('Error updating todo:', error);
    }
  };

  return (
    <div className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <div className="todo-info">
        <h4>{todo.title}</h4>
        <p>{todo.description}</p>
      </div>
      <div className="todo-actions">
        <button onClick={handleComplete}>
          {todo.completed ? 'Undo' : 'Complete'}
        </button>
        <button onClick={handleDelete}>Delete</button>
      </div>
    </div>
  );
};

export default TodoItem;
